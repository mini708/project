var React = require('react');
var firebase = require('firebase');
var history = require('react-router').hashHistory;

var user_logout = React.createClass({
	componentDidMount() {
		firebase.auth().signOut();
		history.push('/login');
	},

	render: function(){
		return <p>Logged out</p>;}
});

module.exports = user_logout;