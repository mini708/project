var React = require('react');
var firebase = require('firebase');
var Link = require('react-router').Link;
var history = require('react-router').hashHistory;

var LogIn = React.createClass({
	getInitialState: function(){
		return{hasError: false};
	},

	handleLogIn: function(){
		var that = this;
		var email = this.refs.email.value;
		var password = this.refs.password.value;

		firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
  			var errorCode = error.code;
  			var errorMessage = error.message;
  			if(error){
  				that.setState({hasError: true});
  				that.setState({errorMsg: "Invalid email or password combination."});
  			}
		});

		this.unsubscribe = firebase.auth().onAuthStateChanged((user) => {
  			if (user) {
				history.push("/");
  			} else {
		    	history.push("/login");
  			}
		});
	},

	componentWillUnmount: function(){
		if (typeof this.unsubscribe == 'function')
		{
			this.unsubscribe(); 
		}
	},
	handleKeyPress: function(e){
		if(e.key == 'Enter'){
			this.handleLogIn();
		}
	},

	render: function(){
		var errorAlert;
		if(this.state.hasError){
			errorAlert = <div className="alert alert-danger"><strong>Error! </strong>{this.state.errorMsg}</div>;
		}else{
			errorAlert = <div></div>;
		}

		return (
			<div>
				{errorAlert}
				<div className="col-md-4">
				</div>

				<div className="col-md-4">
					<center>
						<h1 className="margin-top-30">Log In</h1><br />
						
						<input type="email" ref="email" placeholder="Email Address" className="form-control" onKeyPress={this.handleKeyPress}/><br />
						<input type="password" ref="password" placeholder="Password" className="form-control" onKeyPress={this.handleKeyPress}/><br />
						<button className="btn btn-primary margin-bottom-10" onClick={this.handleLogIn}>Login</button><br />
						No account? <Link to="/signup">Sign up!</Link>
					</center>
				</div>

				<div className="col-md-4">
				</div>

			</div>
			);
	}
});

module.exports = LogIn;