var React = require('react');
var firebase = require('firebase');
var Link = require('react-router').Link;
var hashHistory = require('react-router').hashHistory;

var Acceptance = React.createClass( {
	getInitialState: function() {
		return {
			currentUserID: "",
			requesters: [],
			matched: [],
			mentor: []
		//	applystatus: ""
		}
	},

	componentWillMount: function() {
		var that = this;
		this.unsubscribe = firebase.auth().onAuthStateChanged((user) => {
			this.setState({currentUserID: user.uid});
			this.connectionRef = firebase.database().ref().child('connections/' + this.state.currentUserID).orderByChild('status').equalTo('awaiting-acceptance');
			this.connectionRef.on("child_added", snap => {
				var requesterID = snap.ref.key;
				var requesterRef = firebase.database().ref().child('users/' + requesterID);
				requesterRef.once("value", snap => {
					var userData = snap.val();
					if(userData) {
						var userInfo = {
							first: userData.first,
							last: userData.last,
							hasProfileImage: userData.hasProfileImage,
							user_id: snap.ref.key,
							imageURL: userData.imageURL,
						};
						var updatedRequesters = that.state.requesters.slice();
		                updatedRequesters.push(userInfo);
		                that.setState({requesters: updatedRequesters});
					}
				});
			});

			this.applyRef = firebase.database().ref().child('applying/' + this.state.currentUserID);
			this.applyRef.on("child_added", snap => {
				var companyID = snap.ref.key;
				this.companyRef = firebase.database().ref().child('applying/' + this.state.currentUserID + '/' + companyID).orderByChild('status').equalTo('canApplY');;
				this.companyRef.on("child_added", snap2 => {
					var opportunityID = snap2.ref.key;
					var opportunityRef = firebase.database().ref().child('user-opportunity/' + companyID + '/' + opportunityID);
					var companyInfoRef = firebase.database().ref().child('users/' + companyID);
					var companyData;
					companyInfoRef.once("value", snap3 => {
						companyData = snap3.val();
					});
					opportunityRef.once("value", snap3 => {
						var userData = snap3.val();
						if(userData) {
							var userInfo = {
								first: userData.name,
								hasProfileImage: companyData.hasProfileImage,
								company_id: snap.ref.key,
								user_id: snap2.ref.key,
								imageURL: companyData.imageURL,
				                company_id :snap.ref.key						
						    };
						    var updatedRequesters = that.state.matched.slice();
		                    updatedRequesters.push(userInfo);
		                    that.setState({matched: updatedRequesters});
					    }
				    });
			    });
            });
		this.applyRef = firebase.database().ref().child('applying/' + this.state.currentUserID);
			this.applyRef.on("child_added", snap => {
				var companyID = snap.ref.key;
				this.companyRef = firebase.database().ref().child('applying/' + this.state.currentUserID + '/' + companyID).orderByChild('status').equalTo('canApplY');;
				this.companyRef.on("child_added", snap2 => {
					var opportunityID = snap2.ref.key;
					var opportunityRef = firebase.database().ref().child('user-mentorship/' + companyID + '/' + opportunityID);
					var companyInfoRef = firebase.database().ref().child('users/' + companyID);
					var companyData;
					companyInfoRef.once("value", snap3 => {
						companyData = snap3.val();
					});
					opportunityRef.once("value", snap3 => {
						var userData = snap3.val();
						if(userData) {
							var userInfo = {
								first: userData.name,
								hasProfileImage: companyData.hasProfileImage,
								company_id: snap.ref.key,
								user_id: snap2.ref.key,
								imageURL: companyData.imageURL,
				                company_id :snap.ref.key						
						    };
						    var updatedRequesters = that.state.mentor.slice();
		                    updatedRequesters.push(userInfo);
		                    that.setState({mentor: updatedRequesters});
					    }
				    });
			    });
            });
		this.applyRefUpdate = firebase.database().ref().child('applying/' + this.state.currentUserID);
			this.applyRefUpdate.on("child_changed", snap => {
				var companyID = snap.ref.key;
				var companyData = snap.val();
				this.companyRefUpdate = firebase.database().ref().child('applying/' + this.state.currentUserID + '/' + companyID);
					this.companyRefUpdate.on("child_changed", snap3 => {
						
						var opportunitykey = snap3.ref.key;
						for (var i = 0; i < this.state.matched.length; i++) {
							if (this.state.matched[i].user_id == opportunitykey) {
								index = i;
							}
						}
						if (index > -1) {
						    var updatedRequesters = this.state.matched.slice();
		                    updatedRequesters.splice(index,1);
		                    that.setState({matched: updatedRequesters});
					    } 
					});
			});
			this.applyRefUpdate = firebase.database().ref().child('applying/' + this.state.currentUserID);
			this.applyRefUpdate.on("child_changed", snap => {
				var companyID = snap.ref.key;
				var companyData = snap.val();
				this.companyRefUpdate = firebase.database().ref().child('applying/' + this.state.currentUserID + '/' + companyID);
					this.companyRefUpdate.on("child_changed", snap3 => {
						
						var opportunitykey = snap3.ref.key;
						for (var i = 0; i < this.state.mentor.length; i++) {
							if (this.state.mentor[i].user_id == opportunitykey) {
								index = i;
							}
						}
						if (index > -1) {
						    var updatedRequesters = this.state.mentor.slice();
		                    updatedRequesters.splice(index,1);
		                    that.setState({mentor: updatedRequesters});
					    } 
					});
			});
			
			this.applyRefUpdate = firebase.database().ref().child('applying/' + this.state.currentUserID);
			this.applyRefUpdate.on("child_removed", snap => {
				var companyID = snap.ref.key;
				var companyData = snap.val();
				this.companyRefUpdate = firebase.database().ref().child('applying/' + this.state.currentUserID + '/' + companyID);
					this.companyRefUpdate.on("child_removed", snap3 => {
						
						var opportunitykey = snap3.ref.key;
						for (var i = 0; i < this.state.matched.length; i++) {
							if (this.state.matched[i].user_id == opportunitykey) {
								index = i;
							}
						}
						if (index > -1) {
						    var updatedRequesters = this.state.matched.slice();
		                    updatedRequesters.splice(index,1);
		                    that.setState({matched: updatedRequesters});
					    } 
					});
			});
			
			this.applyRefUpdate = firebase.database().ref().child('applying/' + this.state.currentUserID);
			this.applyRefUpdate.on("child_removed", snap => {
				var companyID = snap.ref.key;
				var companyData = snap.val();
				this.companyRefUpdate = firebase.database().ref().child('applying/' + this.state.currentUserID + '/' + companyID);
					this.companyRefUpdate.on("child_removed", snap3 => {
						
						var opportunitykey = snap3.ref.key;
						for (var i = 0; i < this.state.mentor.length; i++) {
							if (this.state.mentor[i].user_id == opportunitykey) {
								index = i;
							}
						}
						if (index > -1) {
						    var updatedRequesters = this.state.mentor.slice();
		                    updatedRequesters.splice(index,1);
		                    that.setState({mentor: updatedRequesters});
					    } 
					});
			});
			this.connectionRefUpdate = firebase.database().ref().child('connections/' + this.state.currentUserID);
			this.connectionRefUpdate.on("child_changed", snap => {
				var userChangedKey = snap.ref.key;
				var index = -1;
				for(var i = 0; i < this.state.requesters.length; i++) {
					if(this.state.requesters[i].user_id == userChangedKey) {
						index = i;
					}
				}
				if(index > -1) {
					var updatedRequesters = this.state.requesters.slice();
		            updatedRequesters.splice(index, 1);
		            this.setState({requesters: updatedRequesters});
	        	}
			});
			this.connectionRefUpdate.on("child_removed", snap => {
				var userChangedKey = snap.ref.key;
				var index = -1;
				for(var i = 0; i < this.state.requesters.length; i++) {
					if(this.state.requesters[i].user_id == userChangedKey) {
						index = i;
					}
				}
				if(index > -1) {
					var updatedRequesters = this.state.requesters.slice();
		            updatedRequesters.splice(index, 1);
		            this.setState({requesters: updatedRequesters});
	        	}
			});
		});
	},
	componentWillUnmount: function() {
		this.connectionRef.off();
		this.connectionRefUpdate.off();
		this.applyRef.off();
		this.applyRefUpdate.off();
		this.companyRefUpdate.off();
		this.companyRef.off();
		this.opportunityRefUpdate.off();
		this.opportunityRef.off();
		this.unsubscribe();
	},

	handleAcceptConnection: function(user) {
		var connectionUpdate = {};
		connectionUpdate['connections/' + this.state.currentUserID + '/' + user.user_id] = {status: "accepted"}
		firebase.database().ref().update(connectionUpdate);
		var connectionOtherUpdate = {};
		connectionOtherUpdate['connections/' + user.user_id + '/' + this.state.currentUserID] = {status: "accepted"}
		firebase.database().ref().update(connectionOtherUpdate);
	},

	handleRemoveConnection: function(user) {
		var connectionRef = firebase.database().ref().child('connections/' + this.state.currentUserID + '/' + user.user_id);
		connectionRef.remove();
		var connectionOtherRef = firebase.database().ref().child('connections/' + user.user_id + '/' + this.state.currentUserID);
		connectionOtherRef.remove();
	},
	handleApplyMatched: function(user) {
		var matchedUpdate = {};
		matchedUpdate['applying/' + this.state.currentUserID + '/' + user.company_id + '/' + user.user_id] = {status: "applied"}
		//this.setState( applystatus : "applied");
		firebase.database().ref().update(matchedUpdate);
	},

	handleRemoveMatched: function(user) {
		var matchedRef = firebase.database().ref().child('applying/' + this.state.currentUserID + '/' + user.company_id + '/' + user.user_id);
		matchedRef.remove();		
		//this.setState( applystatus : "removed");
	},
handleApplyMentor: function(user) {
		var matchedUpdate = {};
		matchedUpdate['applying/' + this.state.currentUserID + '/' + user.company_id + '/' + user.user_id] = {status: "applied"}
		//this.setState( applystatus : "applied");
		firebase.database().ref().update(matchedUpdate);
	},

	handleRemoveMentor: function(user) {
		var matchedRef = firebase.database().ref().child('applying/' + this.state.currentUserID + '/' + user.company_id + '/' + user.user_id);
		matchedRef.remove();		
		//this.setState( applystatus : "removed");
	},
	showAwaitingAcceptance: function(user) {
		return(
			<div>
				<button className='btn btn-primary request-button' onClick={this.handleAcceptConnection.bind(null, user)}>Accept Connection</button>
				<button className='btn btn-default request-button' onClick={this.handleRemoveConnection.bind(null, user)}>Delete Request</button>
			</div>
		);
	},
	showAwaitingAcceptanceMatched: function(user) {
		return(
			<div>
				<button className='btn btn-primary request-button' onClick={this.handleApplyMatched.bind(null, user)}>Apply</button>
				<button className='btn btn-default request-button' onClick={this.handleRemoveMatched.bind(null, user)}>Delete</button>
			</div>
		);
	},
	showAwaitingAcceptanceMentor: function(user) {
		return(
			<div>
				<button className='btn btn-primary request-button' onClick={this.handleApplyMentor.bind(null, user)}>Apply</button>
				<button className='btn btn-default request-button' onClick={this.handleRemoveMentor.bind(null, user)}>Delete</button>
			</div>
		);
	},

	render: function() {
		var showRequests;
		var showmatched;
		if(this.state.requesters.length == 0 && this.state.matched.length == 0) {
			showRequests = <div><center>No new requests!</center></div>
		} 
		if (this.state.requesters.length != 0) {
			showRequests = 
				this.state.requesters.map((user,index) => (
        			<div className="grid-item col-md-3" key={index}>
       					<Link to={"users/" + user.user_id}><h4><img src={user.imageURL} className="grid-img img-circle" alt="" width="100" height="100" style={{objectFit: 'cover'}}/><br/>
       					{user.first + " " + user.last}</h4></Link>
        				{this.showAwaitingAcceptance(user)}
        				
        			</div>
   				))
		}
		if (this.state.matched.length != 0) {
			showmatched = 
				this.state.matched.map((user,index) => (
        			<div className="grid-item col-md-3" key={index}>
       					<Link to={"user-opportunity/" + user.user_id}><h4><img src={user.imageURL} className="grid-img img-circle" alt="" width="100" height="100" style={{objectFit: 'cover'}}/><br/>
       					{user.first }</h4></Link>
        				{this.showAwaitingAcceptanceMatched(user)}
        				
        			</div>
   				))
		}
		if (this.state.mentor.length != 0) {
			showmatched = 
				this.state.mentor.map((user,index) => (
        			<div className="grid-item col-md-3" key={index}>
       					<Link to={"users/" + user.user_id}><h4><img src={user.imageURL} className="grid-img img-circle" alt="" width="100" height="100" style={{objectFit: 'cover'}}/><br/>
       					{user.first }</h4></Link>
        				{this.showAwaitingAcceptanceMentor(user)}
        				
        			</div>
   				))
		}
		return(
			<div>
				<center><h1 className="grid-title">Requests</h1></center>
				{showRequests}
				{showmatched}
				
			</div>
		);
	}
});

module.exports = Acceptance;
