var React = require('react');
var ReactDOM = require('react-dom');
var firebase = require('firebase');
var Link = require('react-router').Link;
var hashHistory = require('react-router').hashHistory;
var Reply = require('./replies.js');

var Home = React.createClass( {
    getInitialState: function() {
        return {postArray: [], username: ""};
    },

    componentWillMount: function() {
        var that = this;
        this.postsRef = firebase.database().ref().child('posts').orderByChild("created_at");
        this.unsubscribe = firebase.auth().onAuthStateChanged(user => {
            if(user){
                this.userRef = firebase.database().ref('users').child(firebase.auth().currentUser.uid);
                this.userRef.on("value", snap => {
                    this.setState({username: snap.val().first + " " + snap.val().last});
                });
            }
        });
        this.postsRef.on("child_added", snap => {
            var post = snap.val();
            post.post_id = snap.ref.key;
            post.user_imgurl = "https://firebasestorage.googleapis.com/v0/b/testingproject-cd660.appspot.com/o/images%2Fdefault.jpg?alt=media&token=23d9c5ea-1380-4bd2-94bc-1166a83953b7";
            var updatedPostArray = this.state.postArray;
            updatedPostArray.push(post);
            this.setState({postArray : updatedPostArray});
            var userRef = firebase.database().ref('users/'+ post.user_id);
            userRef.once('value', snap => {
                post.user_imgurl = snap.val().imageURL;
                var index = -1;
                for(var i = 0; i < this.state.postArray.length; i++) {
                    if(this.state.postArray[i].post_id == post.post_id) {
                        index = i;
                    }
                }
                var updatedPostArray = this.state.postArray;
                updatedPostArray.splice(index, 1, post);
                this.setState({postArray: updatedPostArray});
            });
        });
        this.postsRef.on("child_changed", snap => {
            var post = snap.val();
            post.post_id = snap.ref.key;
            var userRef = firebase.database().ref('users/'+ post.user_id);
            userRef.once('value', snap => {
                post.user_imgurl = snap.val().imageURL;
                var index;
                for(var i = 0; i < this.state.postArray.length; i++) {
                    if(this.state.postArray[i].post_id == post.post_id) {
                        index = i;
                    }
                }
                var updatedPostArray = this.state.postArray;
                updatedPostArray.splice(index, 1, post);
                this.setState({postArray: updatedPostArray});
            });
        });
    },

    componentWillUnmount: function() {
        this.postsRef.off();
    }, 

    handlePost: function() {
        if(this.refs.body.value){
            var postData = {
                user_id: firebase.auth().currentUser.uid,
                user_name: this.state.username,
                body: this.refs.body.value,
                created_at: firebase.database.ServerValue.TIMESTAMP,
                replies: [],
                likes: 0
            };
            var postRefKey = firebase.database().ref().child('posts').push().key;
            firebase.database().ref('posts/' + postRefKey).set(postData);
            firebase.database().ref('/user-posts/' + firebase.auth().currentUser.uid + '/' + postRefKey).set(postData);
            this.refs.body.value = "";
        }
    },

    handleLike: function(post) {
        if(post.user_id != firebase.auth().currentUser.uid){
            var ref = firebase.database().ref('/user-likes/' + firebase.auth().currentUser.uid + '/' + post.post_id);
            ref.once('value', snap => {
                if(snap.val() && snap.val().liked){
                    var userLikesRef = firebase.database().ref('user-likes/' + firebase.auth().currentUser.uid + '/' + post.post_id);
                    userLikesRef.remove();
                    post.likes-=1;
                }else {
                    var likeUpdate = {};
                    likeUpdate['/user-likes/' + firebase.auth().currentUser.uid + '/' + post.post_id] = {liked: true}
                    firebase.database().ref().update(likeUpdate);
                    post.likes += 1;
                }
                var anotherPost = JSON.parse(JSON.stringify(post));
                delete anotherPost.post_id;
                var updates = {};
                updates['/posts/' + post.post_id] = anotherPost;
                updates['/user-posts/' + post.user_id + '/' + post.post_id] = anotherPost;
                firebase.database().ref().update(updates);
            });
        }
    },

    handleKeyPress: function(e) {
        if(e.key == 'Enter') {
            try{
                this.handlePost();
            }
            catch(e){};
        }
    },

    render: function() {
        var reversedPost = Array.prototype.slice.call(this.state.postArray);
        reversedPost.reverse();
        var dateTimeCustomization = {
            year: "numeric", month: "short",
            day: "numeric", hour: "2-digit", minute: "2-digit"
        }

        return (
            <div>
                <center><h1>Connection Feed</h1></center><br />
                <div className="update-post-container">
                    <input type="text" ref="body" placeholder="What are you thinking about?" onKeyPress={this.handleKeyPress} className="form-control update-post"/><br />
                </div>
                {reversedPost.map((post,index) => (
                    <div key={index} className="post">
                        <table>
                            <tbody>
                            <tr>
                                <td rowSpan='2' style={{padding: '0 5px 0 0'}}>
                                    <Link to={"/users/"+post.user_id}><img src={post.user_imgurl} width="80" height="80" style={{objectFit: 'cover'}}/></Link>
                                </td>
                                <td className="post-username" style={{padding: '0 0 0 5px', verticalAlign: 'bottom'}}>
                                    <Link to={"/users/"+post.user_id}>{post.user_name}</Link>
                                </td>
                            </tr>
                            <tr>
                                <td style={{padding: '0 0 0 5px', color: '#9f9f9f', verticalAlign: 'top'}}>
                                    {(new Date(post.created_at)).toLocaleTimeString("en-US", dateTimeCustomization)}
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <blockquote>
                            {post.body}<br/>
                            <button className="btn btn-default" onClick={this.handleLike.bind(null, post)}><span className="glyphicon glyphicon-thumbs-up"></span> ({post.likes})</button>
                        </blockquote>
                        <hr/>
                        <Reply post_id={post.post_id} username={this.state.username}/>
                    </div>
                ))}
            </div>
        );
    }
});

module.exports = Home;
