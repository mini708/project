var React = require('react');
var firebase = require('firebase');
var Link = require('react-router').Link;
var hashHistory = require('react-router').hashHistory;

var Mentorship = React.createClass ( { 
    
	getInitialState: function() { 
		return { isCurrentUser: false,
		         editing: false,
		         mentorships: [],
		         id: this.props.pageID,
		         matching: [],
		         applying:[],
	      		 matched:[] 
		};
	 },

	componentWillMount: function() { 
        this.mentorshipRef = firebase.database().ref().child ('user-mentorship/'+this.props.pageID);
        this.mentorshipRef.on ("child_added", snap =>  { 
        	var mentorship = snap.val();
			if (mentorship) { 
				mentorship.key = snap.ref.key;
				this.state.mentorships.push (mentorship);
				this.state.matching.push(mentorship);
				this.state.applying.push(mentorship);
				this.setState ( { mentorships: this.state.mentorships } );
				this.userRef = firebase.database().ref().child ('users');
                this.userRef.on ("child_added", snap1 =>  { 
        	        var users = snap1.val();
					var count = 0;
					if (users.mentor == "Yes") {
						count = 1;
			    
					}
					            if (count > 0) {
						            this.state.matched.push(snap1.ref.key);
						            this.setState( { matched: this.state.matched} );
					            }
				        
		            
                });
		   
	
		    this.setState( { matching: this.state.matching} );
		    this.setState( { applying: this.state.applying} );
	        }  
        });
        this.mentorshipRefChanged = firebase.database().ref().child ('user-mentorship/'+this.props.pageID);
        this.mentorshipRefChanged.on ("child_changed", snap =>  { 
        	var mentorship = snap.val();
			if (mentorship) { 
				mentorship.key = snap.ref.key;
				var index;
				for (var i = 0; i < this.state.mentorships.length; i++) { 
					if (this.state.mentorships[i].key == mentorship.key) { 
						index = i;
					 }  
				 }  
				this.state.mentorships.splice (index, 1, mentorship);
				this.setState ( { mentorships: this.state.mentorships }  );
				this.state.matching.splice (index, 1, mentorship);
				this.setState ( { matching: this.state.matching }  );
				this.state.applying.splice (index, 1, mentorship);
				this.setState ( { applying: this.state.applying }  );
			 }  
         });
        this.mentorshipRefRemoved = firebase.database().ref().child ('user-mentorship/'+this.props.pageID);
        this.mentorshipRefRemoved.on ("child_removed", snap =>  { 
        	var mentorship = snap.val();
			if (mentorship) { 
				mentorship.key = snap.ref.key;
				var index;
				for (var i = 0; i < this.state.mentorships.length; i++) { 
					if (this.state.mentorships[i].key == mentorship.key) { 
						index = i;
					 }  
				 }  
				this.state.mentorships.splice (index, 1);
				this.setState ( { mentorships: this.state.mentorships }  );
				this.state.matching.splice (index, 1 );
				this.setState ( { matching: this.state.matching }  );
				this.state.applying.splice (index, 1 );
				this.setState ( { applying: this.state.applying }  );
			 }  
         });
	 },
	componentWillReceiveProps: function (nextProps) { 
		if (nextProps.pageID != this.state.id) { 
			this.mentorshipRef.off();
			this.mentorshipRefChanged.off();
			this.mentorshipRefRemoved.off();
			this.setState ( { mentorships: [] }  );
			this.mentorshipRef = firebase.database().ref().child('user-mentorship/'+ nextProps.pageID);
	        this.mentorshipRef.on("child_added", snap =>  { 
	        	var mentorship = snap.val();
				if (mentorship) { 
					mentorship.key = snap.ref.key;
					this.state.mentorships.push (mentorship);
					this.setState ( { mentorships: this.state.mentorships }  );
 					this.state.matching.push (mentorship);
					this.userRef = firebase.database().ref().child ('users');
                    this.userRef.on ("child_added", snap1 =>  { 
        	            var users = snap1.val();
						var count = 0;
						if (users.mentor == "Yes") {
							count = 1;
				 }
					            if (count > 0) {
						            this.state.matched.push(snap1.ref.key);
						            this.setState( { matched: this.state.matched} );
					            }
		            
			        this.setState ( { matching: this.state.matching }  );
			        this.state.applying.push (mentorship);
		    	    this.setState ( { applying: this.state.applying }  );
		        });}  
	        });
	        this.mentorshipRefChanged = firebase.database().ref().child ('user-mentorship/' + nextProps.pageID);
	        this.mentorshipRefChanged.on ("child_changed", snap =>  { 
	            var mentorship = snap.val();
			    if (mentorship) { 
				    mentorship.key = snap.ref.key;
				    var index;
				    for (var i = 0; i < this.state.mentorships.length; i++) { 
				        if (this.state.mentorships[i].key == mentorship.key) { 
					    	index = i;
					    }  
				    }  
				    this.state.mentorships.splice (index, 1, mentorship);
				    this.setState ( { mentorships: this.state.mentorships });
    				this.state.matching.splice (index, 1, mentorship);
	    			this.setState ( { matching: this.state.matching }  );
		    		this.state.applying.splice (index, 1, mentorship);
			    	this.setState ( { applying: this.state.applying }  );
	    		}  
	        });
	        this.mentorshipRefChanged = firebase.database().ref().child ('user-mentorship/' + nextProps.pageID);
	        this.mentorshipRefChanged.on ("child_removed", snap =>  { 
	            var mentorship = snap.val();
			    if (mentorship) { 
    				mentorship.key = snap.ref.key;
	    			var index;
		    		for (var i = 0; i < this.state.mentorships.length; i++) { 
			    		if (this.state.mentorships[i].key == mentorship.key) { 
				    		index = i;
					     }  
		    		 }  
			    	this.state.mentorships.splice (index, 1);
				    this.setState ( { mentorships: this.state.mentorships }  );
    				this.state.matching.splice (index, 1);
	    			this.setState ( { matching: this.state.matching }  );
		    		this.state.applying.splice (index, 1);
			    	this.setState ( { applying: this.state.applying }  );
			    }  
	        });
        }  
	 },

	handleClickAdd: function() { 
		this.setState ( { adding: true }  );
	 },

	handleClickEdit: function(index) { 
		this.setState ( { editing: true }  );
		this.setState ( { indexToEdit: index }  );
	 },
	 
	handleClickSave: function() { 
		var mentorshipData =  { 
			mentor: this.refs.mentor == "false" ? false : true,
			name: this.refs.name.value,
			company: this.refs.company.value,
			startDate: this.refs.startDate.value,
			endDate: this.refs.endDate.value,
			weeklyhours: this.refs.weeklyhours.value,
			year: this.refs.year.value,
			skills: this.refs.skills.value,
			accommodation: this.refs.accommodation == "true" ? true : false,
			location: this.refs.location.value,
			pay: this.refs.pay.value,
			description: this.refs.description.value

		 }  
		var matchingUser = {
			status : "matched"
		}
		var applyingUser = {
			status : "canApplY"
		}
		if(this.state.editing) { 
			var mentorshipUpdate =  {  }  ;
			mentorshipUpdate['/user-mentorship/' + this.props.pageID + '/' + this.state.mentorships[this.state.indexToEdit].key] = mentorshipData;
			firebase.database().ref().update(mentorshipUpdate);

		 }  else { 
			var newmentorshipKey = firebase.database().ref().child('mentorship').push().key;
			firebase.database().ref('/user-mentorship/' + this.props.pageID + '/' + newmentorshipKey).set(mentorshipData);
			for (var i = 0; i < this.state.matched.length; i++) {
				firebase.database().ref('/matching/' + this.props.pageID + '/' + newmentorshipKey + '/' + this.state.matched[i]).set(matchingUser);
				firebase.database().ref('/applying/' +this.state.matched[i]+ '/' + this.props.pageID + '/' + newmentorshipKey ).set(applyingUser);
			}}
			 
		this.setState ( { editing: false }  );
		this.setState ( { adding: false }  );
	 }  ,
	handleRemoveExisting: function() { 
		var mentorshipRef = firebase.database().ref('user-mentorship/' + this.props.pageID + '/' + this.state.mentorships[this.state.indexToEdit].key);
		mentorshipRef.remove();
		var matchingRef = firebase.database().ref('matching/' + this.props.pageID + '/' + this.state.mentorships[this.state.indexToEdit].key);
		matchingRef.remove();
		

		this.setState ( { editing: false }  );
		this.setState ( { adding: false }  );
	 }  ,
	handleClickCancel: function() { 
		this.setState ( { editing: false }  );
		this.setState ( { adding: false }  );
	 }  ,
	mentorshipHeading: function() { 
		if(this.props.isCurrentUser) { 
			return <h4 className="profile-heading"> Mentorship <button className="btn btn-default" onClick= { this.handleClickAdd }  ><span className="glyphicon glyphicon-plus" title="Add mentorship"></span></button></h4>
		 }  else { 
			return <h4 className="profile-heading"> Mentorship </h4>
		 }  
	 }  ,
	addingmentorship: function() { 
		var show;
		return (
			<div className="col-md-12">
				<div className="col-md-8">
					<input type="radio"  name="mentor" value="false" onChange={this.accountChange} className="radio-selection"/><span className="radio-selection">Outside Organization</span>
					<input type="radio"  name="mentor" value="true" onChange={this.accountChange} className="radio-selection"/><span className="radio-selection">Within Organization</span><br /><br />
					<h4> Mentorship Name </h4>
					<input type="text" ref="name" className="form-control"/><br />
					<h4> Company </h4>
					<input type="text" ref="company" className="form-control" placeholder="Linkedin"/><br />
					<h4> Time Period </h4>
					<div className="input-group">
						<input type="month" ref="startDate" className="form-control"  />
						<span className="input-group-addon">-</span>
						<input type="month" ref="endDate" className="form-control"  />
					</div><br/>
					<h4> Weekly Hours </h4>
					<input type="number" ref="weeklyhours" className="form-control" placeholder="0"/><br />
					<h4> Experience Required </h4>
					<input type="number" ref="year" className="form-control" placeholder="0"/><br />
					<h4> Skills </h4>
					<input type="text" ref="skills" className="form-control" placeholder="Machine Learning"/><br />
					<h4> Accommodation Required </h4>
					<input type="radio" name="accommodation" value="true" onChange={this.accountChange} className="radio-selection"/><span className="radio-selection">Yes</span>
					<input type="radio" name="accommodation" value="false" onChange={this.accountChange} className="radio-selecion"/><span className="radio-selection">No</span><br /><br />
					<h4> Location </h4>
					<input type="text" ref="location" className="form-control" placeholder="Bengaluru, New York"/><br />
					<h4> Pay </h4>
					<input type="number" ref="pay" className="form-control" placeholder="1200USD"/><br />
					<h4> Description </h4>
					<input type="text" ref="description" className="form-control" /><br />
					<center>
						<div className="btn btn-toolbar">
							<button className="btn btn-primary" onClick= { this.handleClickSave }  >Save</button>
							<button className="btn btn-default" onClick= { this.handleClickCancel }  >Cancel</button>
						</div>
					</center><br/>
					
				</div>
			</div>
		)
	 }  ,
	editingmentorship: function() { 
		var indexedmentorship = this.state.mentorships[this.state.indexToEdit];
		return (
			<div className="col-md-12">
				<div className="col-md-8">
					<input type="radio" name="mentor" value="false" onChange={this.accountChange} className="radio-selection"/><span className="radio-selection">Outside Organization</span>
					<input type="radio" name="mentor" value="true" onChange={this.accountChange} className="radio-selection"/><span className="radio-selection">Within Organization</span><br /><br />
					<h4> Mentorship Name </h4>
					<input type="text" ref="name" className="form-control"/><br />
					<h4> Company </h4>
					<input type="text" ref="company" className="form-control" placeholder="Linkedin"/><br />
					<h4> Time Period </h4>
					<div className="input-group">
						<input type="month" ref="startDate" className="form-control"  />
						<span className="input-group-addon">-</span>
						<input type="month" ref="endDate" className="form-control"  />
					</div><br/>
					<h4> Weekly Hours </h4>
					<input type="number" ref="weeklyhours" className="form-control" placeholder="0"/><br />
					<h4> Experience Required </h4>
					<input type="number" ref="year" className="form-control" placeholder="0"/><br />
					<h4> Skills </h4>
					<input type="text" ref="skills" className="form-control" placeholder="Machine Learning"/><br />
					<h4> Accommodation Required </h4>
					<input type="radio" name="accommodation" value="true" onChange={this.accountChange} className="radio-selection"/><span className="radio-selection">Yes</span>
					<input type="radio" name="accommodation" value="false" onChange={this.accountChange} className="radio-selection"/><span className="radio-selection">No</span><br /><br />
					<h4> Location </h4>
					<input type="text" ref="location" className="form-control" placeholder="Bengaluru, New York"/><br />
					<h4> Pay </h4>
					<input type="number" ref="pay" className="form-control" placeholder="1200USD"/><br />
					<h4> Description </h4>
					<input type="text" ref="description" className="form-control" /><br />
					<center>
						<div className="btn btn-toolbar">
							<button className="btn btn-primary" onClick= { this.handleClickSave }  >Save</button>
							<button className="btn btn-default" onClick= { this.handleClickCancel }  >Cancel</button>
							<button className="btn btn-link" onClick= { this.handleRemoveExisting }  >Remove this mentorship</button>
						</div>
					</center>
				</div>
			</div>
		)
	 }  ,
	defaultmentorship: function() { 
		if(this.props.isCurrentUser) { 
			return(
				<div>
				 { this.state.mentorships.map((mentorship,index) => (
			        	<div key= { index }  >
		       			    <h4><strong> { mentorship.name }  </strong> <button className="btn btn-default" onClick= { this.handleClickEdit.bind(null, index) }  ><span className="glyphicon glyphicon-pencil" title="Edit mentorship"></span></button></h4>
			       		    <h5> { mentorship.mentor }  </h5>
			       		    <h5> { mentorship.company }  </h5>
			       			<h5> { mentorship.startDate }  </h5>
			       			<h5> { mentorship.endDate }  </h5>
			       			<h5> { mentorship.weeklyhours }  </h5>
							<h5> { mentorship.year }  </h5>
						    <h5> { mentorship.skills }  </h5>
			       			<h5> { mentorship.accommodation }  </h5>
							<h5> { mentorship.location }  </h5>
			       			<h5> { mentorship.pay }  </h5>
							<h5> { mentorship.description }  </h5>
			
			       		</div>
			   		)) }  
				</div>
			)
		 }  else { 
			return(
				<div>
				 { this.state.mentorships.map((mentorship,index) => (
			        	<div key= { index }  >
			       			<h4><strong> { mentorship.name }  </strong></h4>
							    <h5> { mentorship.mentor }  </h5>
							   <h5> { mentorship.company }  </h5>
			       			<h5> { mentorship.startDate }  </h5>
			       			<h5> { mentorship.endDate }  </h5>
			       			<h5> { mentorship.weeklyhours }  </h5>
							<h5> { mentorship.year }  </h5>
						    <h5> { mentorship.skills }  </h5>
			       			<h5> { mentorship.accommodation }  </h5>
							<h5> { mentorship.location }  </h5>
			       			<h5> { mentorship.pay }  </h5>
							<h5> { mentorship.description }  </h5>
			       		</div>
			   		)) }  
				</div>
			)
		 }  
	 }  ,
	render: function() { 
		var show;
		if(this.state.adding) { 
			show = this.addingmentorship();
		 }  else if(this.state.editing) { 
			show = this.editingmentorship();
		 }  else { 
			show = this.defaultmentorship();
		 }  
		return (
			<div>
				 { this.mentorshipHeading() }  
				 { show }  
				<hr></hr>
			</div>
		)
	 },
	componentWillUnmount: function() { 
		this.mentorshipRef.off();
		this.mentorshipRefChanged.off();
		this.mentorshipRefRemoved.off();
	 },
 });
module.exports = Mentorship;

