var React = require('react');
var firebase = require('firebase');
var Link = require('react-router').Link;
var hashHistory = require('react-router').hashHistory;

var opportunity = React.createClass ( { 
    
	getInitialState: function() { 
		return { isCurrentUser: false,
		         editing: false,
		         opportunities: [],
		         id: this.props.pageID,
		         matching: [],
		         applying:[],
	      		 matched:[] 
		};
	 },
	componentWillMount: function() { 
        this.opportunityRef = firebase.database().ref().child ('user-opportunity/'+this.props.pageID);
        this.opportunityRef.on ("child_added", snap =>  { 
        	var opportunity = snap.val();
			if (opportunity) { 
				opportunity.key = snap.ref.key;
				this.state.opportunities.push (opportunity);
				this.state.matching.push(opportunity);
				this.state.applying.push(opportunity);
				this.setState ( { opportunities: this.state.opportunities } );
				this.userRef = firebase.database().ref().child ('users');
                this.userRef.on ("child_added", snap1 =>  { 
        	        var users = snap1.val();
		            var count = 0;
			       if (users) { 
				            users.key = snap1.ref.key;
				            if (!users.recruiter) {
					            if (users.location == opportunity.location || opportunity.location == "") {
						            count++;	
                                } else {
                                        count = count - 4;
                                } 
					            if (users.gender == opportunity.gender || opportunity.gender == "" ||  opportunity.gender == "Both") {
					                count++;	
                                } else {
                                    count = count - 4;
                                }
					            this.educationRef = firebase.database().ref().child ('user-education' + '/' + users.key);
        				        this.educationRef.on ("child_added", snap2 =>  { 
        					        var educations = snap2.val();					
						            if (educations) {
							            educations.key = snap2.ref.key;
							            if (educations.major == opportunity.course || educations.degree == opportunity.course || opportunity.course == "") {
								            count++;
							            } else {
							                count = count - 4;
							            } 
							            if (educations.endDate == opportunity.year || opportunity.year == "") {
								            count++;
							            } else {
							                count = count - 4;
							            }
						            }	
					           });
					            if (count > 0) {
						            this.state.matched.push(users);
						            this.setState( { matched: this.state.matched} );
					            }
				        }

		            } 
                });
		   
	
		    this.setState( { matching: this.state.matching} );
		    this.setState( { applying: this.state.applying} );
	        }  
        });
        this.opportunityRefChanged = firebase.database().ref().child ('user-opportunity/'+this.props.pageID);
        this.opportunityRefChanged.on ("child_changed", snap =>  { 
        	var opportunity = snap.val();
			if (opportunity) { 
				opportunity.key = snap.ref.key;
				var index;
				for (var i = 0; i < this.state.opportunities.length; i++) { 
					if (this.state.opportunities[i].key == opportunity.key) { 
						index = i;
					 }  
				 }  
				this.state.opportunities.splice (index, 1, opportunity);
				this.setState ( { opportunities: this.state.opportunities }  );
				this.state.matching.splice (index, 1, opportunity);
				this.setState ( { matching: this.state.matching }  );
				this.state.applying.splice (index, 1, opportunity);
				this.setState ( { applying: this.state.applying }  );
			 }  
         });
        this.opportunityRefRemoved = firebase.database().ref().child ('user-opportunity/'+this.props.pageID);
        this.opportunityRefRemoved.on ("child_removed", snap =>  { 
        	var opportunity = snap.val();
			if (opportunity) { 
				opportunity.key = snap.ref.key;
				var index;
				for (var i = 0; i < this.state.opportunities.length; i++) { 
					if (this.state.opportunities[i].key == opportunity.key) { 
						index = i;
					 }  
				 }  
				this.state.opportunities.splice (index, 1);
				this.setState ( { opportunities: this.state.opportunities }  );
				this.state.matching.splice (index, 1 );
				this.setState ( { matching: this.state.matching }  );
				this.state.applying.splice (index, 1 );
				this.setState ( { applying: this.state.applying }  );
			 }  
         });
	 },
	componentWillReceiveProps: function (nextProps) { 
		if (nextProps.pageID != this.state.id) { 
			this.opportunityRef.off();
			this.opportunityRefChanged.off();
			this.opportunityRefRemoved.off();
			this.setState ( { opportunities: [] }  );
			this.opportunityRef = firebase.database().ref().child('user-opportunity/'+ nextProps.pageID);
	        this.opportunityRef.on("child_added", snap =>  { 
	        	var opportunity = snap.val();
				if (opportunity) { 
					opportunity.key = snap.ref.key;
					this.state.opportunities.push (opportunity);
					this.setState ( { opportunities: this.state.opportunities }  );
 					this.state.matching.push (opportunity);
					this.userRef = firebase.database().ref().child ('users');
                    this.userRef.on ("child_added", snap1 =>  { 
        	            var users = snap1.val();
		                var count = 0;
			        if (users) { 
				            users.key = snap1.ref.key;
				            if (!users.recruiter) {
					            if (users.location == opportunity.location || opportunity.location == "") {
						            count++;	
                                } else {
                                    count = count - 4;
                                }
					            if (users.gender == opportunity.gender || opportunity.gender == "" ||  opportunity.gender == "Both") {
					                count++;	
                                } else {
                                    count = count - 4;
                                }
					            this.educationRef = firebase.database().ref().child ('user-education' + '/' + users.key);
        				        this.educationRef.on ("child_added", snap2 =>  { 
        					        var educations = snap2.val();					
						            if (educations) {
							            educations.key = snap2.ref.key;
							            if (educations.major == opportunity.course || educations.degree == opportunity.course || opportunity.course == "") {
								            count++;
							            } else {
                                            count = count - 4;
                                        } 
							            if (educations.endDate == opportunity.year || opportunity.year == "") {
								            count++;
							            } else {
                                            count = count - 4;
                                        }
						            }	
					            });
					            if (count > 0) {
						            this.state.matched.push(users);
						            this.setState( { matched: this.state.matched} );
					            }
				       }

		            } 
			        this.setState ( { matching: this.state.matching }  );
			        this.state.applying.push (opportunity);
		    	    this.setState ( { applying: this.state.applying }  );
		        });}  
	        });
	        this.opportunityRefChanged = firebase.database().ref().child ('user-opportunity/' + nextProps.pageID);
	        this.opportunityRefChanged.on ("child_changed", snap =>  { 
	            var opportunity = snap.val();
			    if (opportunity) { 
				    opportunity.key = snap.ref.key;
				    var index;
				    for (var i = 0; i < this.state.opportunities.length; i++) { 
				        if (this.state.opportunities[i].key == opportunity.key) { 
					    	index = i;
					    }  
				    }  
				    this.state.opportunities.splice (index, 1, opportunity);
				    this.setState ( { opportunities: this.state.opportunities });
    				this.state.matching.splice (index, 1, opportunity);
	    			this.setState ( { matching: this.state.matching }  );
		    		this.state.applying.splice (index, 1, opportunity);
			    	this.setState ( { applying: this.state.applying }  );
	    		}  
	        });
	        this.opportunityRefChanged = firebase.database().ref().child ('user-opportunity/' + nextProps.pageID);
	        this.opportunityRefChanged.on ("child_removed", snap =>  { 
	            var opportunity = snap.val();
			    if (opportunity) { 
    				opportunity.key = snap.ref.key;
	    			var index;
		    		for (var i = 0; i < this.state.opportunities.length; i++) { 
			    		if (this.state.opportunities[i].key == opportunity.key) { 
				    		index = i;
					     }  
		    		 }  
			    	this.state.opportunities.splice (index, 1);
				    this.setState ( { opportunities: this.state.opportunities }  );
    				this.state.matching.splice (index, 1);
	    			this.setState ( { matching: this.state.matching }  );
		    		this.state.applying.splice (index, 1);
			    	this.setState ( { applying: this.state.applying }  );
			    }  
	        });
        }  
	 },

	handleClickAdd: function() { 
		this.setState ( { adding: true }  );
	 },

	handleClickEdit: function(index) { 
		this.setState ( { editing: true }  );
		this.setState ( { indexToEdit: index }  );
	 },
	 
	handleClickSave: function() { 
		var opportunityData =  { 
			location: this.refs.location.value,
			outcome: this.refs.outcome.value,
			process: this.refs.process.value,
			gender: this.refs.gender.value,
			name: this.refs.name.value,
			deadline: this.refs.deadline.value,
			year: this.refs.year.value,
			amount: this.refs.amount.value,
			course: this.refs.course.value,
			status : this.state.matched.length,
			weblink: this.refs.weblink.value
		 }  
		var matchingUser = {
			status : "matched"
		}
		var applyingUser = {
			status : "canApplY"
		}
		if(this.state.editing) { 
			var opportunityUpdate =  {  }  ;
			opportunityUpdate['/user-opportunity/' + this.props.pageID + '/' + this.state.opportunities[this.state.indexToEdit].key] = opportunityData;
			firebase.database().ref().update(opportunityUpdate);

		 }  else { 
			var newopportunityKey = firebase.database().ref().child('opportunity').push().key;
			firebase.database().ref('/user-opportunity/' + this.props.pageID + '/' + newopportunityKey).set(opportunityData);
			for (var i = 0; i < this.state.matched.length; i++) {
				firebase.database().ref('/matching/' + this.props.pageID + '/' + newopportunityKey + '/' + this.state.matched[i].key).set(matchingUser);
				firebase.database().ref('/applying/' +this.state.matched[i].key + '/' + this.props.pageID + '/' + newopportunityKey ).set(applyingUser);
			}}
			 
		this.setState ( { editing: false }  );
		this.setState ( { adding: false }  );
	 }  ,
	handleRemoveExisting: function() { 
		var opportunityRef = firebase.database().ref('user-opportunity/' + this.props.pageID + '/' + this.state.opportunities[this.state.indexToEdit].key);
		opportunityRef.remove();
		var matchingRef = firebase.database().ref('matching/' + this.props.pageID + '/' + this.state.opportunities[this.state.indexToEdit].key);
		matchingRef.remove();
		

		this.setState ( { editing: false }  );
		this.setState ( { adding: false }  );
	 }  ,
	handleClickCancel: function() { 
		this.setState ( { editing: false }  );
		this.setState ( { adding: false }  );
	 }  ,
	opportunityHeading: function() { 
		if(this.props.isCurrentUser) { 
			return <h4 className="profile-heading">Opportunity Listing<button className="btn btn-default" onClick= { this.handleClickAdd }  ><span className="glyphicon glyphicon-plus" title="Add opportunity"></span></button></h4>
		 }  else { 
			return <h4 className="profile-heading">Opportunity Listing</h4>
		 }  
	 }  ,
	addingopportunity: function() { 
		var show;
		return (
			<div className="col-md-12">
				<div className="col-md-8">
					<h4> Opportunity Name </h4>
					<input type="text" ref="name" className="form-control"/><br />
					<h4> Dead Line </h4>
					<input type="Date" ref="deadline" className="form-control" placeholder="02 - 02 - 2020"/><br />
					<h4> Gender </h4>
					<input type="text" ref="gender" className="form-control" placeholder="Female"/><br />	
					<h4> Graduation Year</h4>
					<input type="text" ref="year" className="form-control" placeholder="2020,2021"/><br />
					<h4> Amount </h4>
					<input type="text" ref="amount" className="form-control" 	placeholder="780 USD"/><br />
					<h4> Course </h4>		
					<input type="text" ref="course" className="form-control" placeholder="BTech - Computer Science"/><br />
					<h4> Location </h4>
					<input type="text" ref="location" className="form-control" placeholder="India, USA"/><br />	
					<h4> Program Outcome</h4>
					<input type="text" ref="outcome" className="form-control" placeholder="Program Outcome"/><br />
					<h4> Step Wise Process </h4>
					<textarea className="form-control" rows="6" style= {  { width: '100%' }   }   ref="process" placeholder="Step Wise Process" /><br/>
					<h4> Webpage Link </h4>
					<textarea className="form-control" rows="6" style= {  { width: '100%' }   }   ref="weblink" placeholder="Link" /><br/>
					<center>
						<div className="btn btn-toolbar">
							<button className="btn btn-primary" onClick= { this.handleClickSave }  >Save</button>
							<button className="btn btn-default" onClick= { this.handleClickCancel }  >Cancel</button>
						</div>
					</center><br/>
			
				</div>
			</div>
		)
	 }  ,
	editingopportunity: function() { 
		var indexedopportunity = this.state.opportunities[this.state.indexToEdit];
		return (
			<div className="col-md-12">
				<div className="col-md-8">
					<h4> Opportunity Name </h4>
					<input type="text" ref="name" className="form-control" defaultValue= { indexedopportunity.name }   /><br />
					<h4> Dead Line </h4>
					<input type="date" ref="deadline" className="form-control" defaultValue= { indexedopportunity.deadline }  /><br />
					<h4> Gender </h4>
					<input type="text" ref="gender" className="form-control" defaultValue= { indexedopportunity.gender}   /><br />
					<h4> Graduation Year</h4>
					<input type="text" ref="year" className="form-control" defaultValue= { indexedopportunity.year }  /><br />
					<h4> Course </h4>
					<input type="text" ref="course" className="form-control" defaultValue= { indexedopportunity.course }   /><br />
					<h4> Amount </h4>
					<input type="text" ref="amount" className="form-control" defaultValue= { indexedopportunity.amount }  /><br />
					<h4> Location </h4>
					<input type="text" ref="location" className="form-control" defaultValue= { indexedopportunity.location }   /><br />
					<h4> Program Outcome</h4>
					<input type="text" ref="outcome" className="form-control" defaultValue= { indexedopportunity.outcome }  /><br />
					<h4> Step Wise Process </h4>
					<textarea className="form-control" rows="6" style= {  { width: '100%' }   }   ref="process" defaultValue= { indexedopportunity.process }  /><br/>
					<h4> Webpage Link </h4>
					<textarea className="form-control" rows="6" style= {  { width: '100%' }   }   ref="weblink" placeholder="Link" /><br/>
					<center>
						<div className="btn btn-toolbar">
							<button className="btn btn-primary" onClick= { this.handleClickSave }  >Save</button>
							<button className="btn btn-default" onClick= { this.handleClickCancel }  >Cancel</button>
							<button className="btn btn-link" onClick= { this.handleRemoveExisting }  >Remove this opportunity</button>
						</div>
					</center><br/>
			
				</div>
			</div>
		)
	 }  ,
	defaultopportunity: function() { 
		if(this.props.isCurrentUser) { 
			return(
				<div>
				 { this.state.opportunities.map((opportunity,index) => (
			        	<div key= { index }  >
		       			    <h4><strong> { opportunity.name }  </strong> <button className="btn btn-default" onClick= { this.handleClickEdit.bind(null, index) }  ><span className="glyphicon glyphicon-pencil" title="Edit opportunity"></span></button></h4>
						    <h5> { opportunity.deadline }  </h5>
			       		    <h5> { opportunity.gender }  </h5>
			       		    <h5> { opportunity.year }  </h5>
						    <h5> { opportunity.course }  </h5>
						    <h5> { opportunity.amount }  </h5>
						    <h5> { opportunity.location }  </h5>
						    <h5> { opportunity.outcome }  </h5>
						    <h5> { opportunity.weblink }  </h5>

			       		    <h6><pre style= {  { margin: "-10px 0px 0px -10px", fontFamily: "helvetica", border: "none", width: "100%", background: "none", whiteSpace: "pre-wrap" }   }  > { opportunity.process }  </pre></h6>
							
			       		</div>
			   		)) }  
				</div>
			)
		 }  else { 
			return(
				<div>
				 { this.state.opportunities.map((opportunity,index) => (
			        	<div key= { index }  >
			       			<h4><strong> { opportunity.name }  </strong></h4>
			       			<h5> { opportunity.deadline }  </h5>
			       			<h5> { opportunity.gender }  </h5>
			       			<h5> { opportunity.year }  </h5>
						    <h5> { opportunity.course }  </h5>
						    <h5> { opportunity.amount }  </h5>
						    <h5> { opportunity.location }  </h5>
						    <h5> { opportunity.outcome }  </h5>
						    <h5> { opportunity.weblink }  </h5>

			       			<h6><pre style= {  { margin: "-10px 0px 0px -10px", fontFamily: "helvetica", border: "none", width: "100%", background: "none", whiteSpace: "pre-wrap" }   }  > { opportunity.process }  </pre></h6>
			       		</div>
			   		)) }  
				</div>
			)
		 }  
	 }  ,
	render: function() { 
		var show;
		if(this.state.adding) { 
			show = this.addingopportunity();
		 }  else if(this.state.editing) { 
			show = this.editingopportunity();
		 }  else { 
			show = this.defaultopportunity();
		 }  
		return (
			<div>
				 { this.opportunityHeading() }  
				 { show }  
				<hr></hr>
			</div>
		)
	 },
	componentWillUnmount: function() { 
		this.opportunityRef.off();
		this.opportunityRefChanged.off();
		this.opportunityRefRemoved.off();
	 },
 });
module.exports = opportunity;

