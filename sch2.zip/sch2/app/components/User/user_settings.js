var React = require('react');
var firebase = require('firebase');
var Link = require('react-router').Link;
var history = require('react-router').hashHistory;
var DeleteAccount = require('./delete_acc.js');

var Settings = React.createClass({
	getInitialState: function(){
		return{hasError: false, errorMsg: "", verified: false, verificationMessage: ""};
	},

	verifyPassword: function(e){
		var that = this;

		if(this.refs.current_password.value){
			var user = firebase.auth().currentUser;
			var credential = firebase.auth.EmailAuthProvider.credential(user.email, this.refs.current_password.value);
			user.reauthenticate(credential).then(function(){
				that.setState({verified: true});
				that.setState({verificationMessage: "Password verified."});
				that.setState({hasError: false});
				that.setState({errorMsg: ""});
			}).catch(function(error){
				that.setState({hasError: true});
				that.setState({errorMsg: "Invalid password."});
				that.setState({verified: false});
				that.setState({verificationMessage: ""});
			});
		}
	},

	handleKeyPress: function(e){
		if(e.key == "Enter"){
			try{
				this.verifyPassword();
			}catch(e){}
		}
	},

	render: function(){
		var alert;
		if(this.state.verified){
			alert = <div className="alert alert-success"><strong>Success! </strong>{this.state.verificationMessage}</div>;}
		else if(this.state.hasError){
			alert = <div className="alert alert-danger"><strong>Error! </strong>{this.state.errorMsg}</div>;
		} else{
			alert = <div className="alert alert-info">Please enter your current password before proceeding</div>;
		}
		var show;
		if(this.state.verified){
			show = 
				<div>
					<DeleteAccount />
				</div>
		}else{
			show = 
				<div>
					<input type="password" ref="current_password" placeholder="Current Password" className="form-control" onKeyPress={this.handleKeyPress}/><br />
					<button className="btn btn-success" onClick={this.verifyPassword}>Verify</button>
				</div>
		}

		return(
			<div>
				{alert}
				<div className="col-md-4">
				</div>
				<div className="col-md-4">
					<center>
						<h1>Account Settings</h1><br />
						{show}
					</center>
				</div>
				<div className="col-md-4">
				</div>
			</div>
		);
	}
});

module.exports = Settings;