var React = require('react');
var firebase = require('firebase');
var Link = require('react-router').Link;
var history = require('react-router').hashHistory;

var DeleteAccount = React.createClass({

	getInitialState: function(){
		return{hasError: false, succeeded: false, errorMsg: "", successMsg: ""};
	},

	deleteAcc: function(){
		if(true){
			var user = firebase.auth().currentUser;

			if(confirm("Are you sure you want to delete your account?")){
				
				var postsRef = firebase.database().ref().child('posts').orderByChild('user_id').equalTo(user.uid);
				postsRef.on('child_added', snap =>{
					var post = snap.ref.remove();
				});
				var userPostsRef = firebase.database().ref('/user-posts/' + user.uid);
				userPostsRef.remove();

				var userRef = firebase.database().ref('users/' + user.uid);
				userRef.remove();

				setTimeout(function() {
					user.delete().then(function(){
						history.push('/');
					}, function(error){
						console.log(error);
					});
				}.bind(this), 2000);
			}
		}
	},

	render: function(){
		return (
			<div>
				<h3 style={{color:'red'}}>Delete</h3>						
				<button onClick={this.deleteAcc} className="btn btn-danger">Delete Account</button><br />
			</div>
		);
	}
});

module.exports = DeleteAccount;