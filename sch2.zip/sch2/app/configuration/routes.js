var React = require('react');
var Router = require('react-router').Router;
var Route = require('react-router').Route;
var IndexRoute = require('react-router').IndexRoute;
var history = require('react-router').hashHistory;

var NewUser = require('../components/User/new_user.js');
var InitSession = require('../components/Session/new_sess.js');
var Home = require('../components/Webpages/homepage.js');
var Logout = require('../components/Session/destroy_sess.js');
var Layout = require('../components/Webpages/PageLayout.js');
var UserSettings = require('../components/User/user_settings.js');
var Profile = require('../components/Profiles/profile.js');
var Acceptance = require('../components/Connections/acceptance.js');
var Connections = require('../components/Connections/index.js');
var SearchResults = require('../components/Webpages/result.js');
var AdvancedSearch = require('../components/Webpages/advanced_search.js');
var Companies = require('../components/Webpages/company.js');

var req_auth = require('./auth.js')

var routes = (
	<Router history={history}>
		<Route path="/" component={Layout}>
			<IndexRoute component={Home} onEnter={req_auth}/>
			<Route path="login" component={InitSession}/>
			<Route path="signup" component={NewUser}/>
			<Route path="logout" component={Logout}/>
			<Route path="accountSettings" component={UserSettings} onEnter={req_auth}/>
			<Route path="users/:id" component={Profile} onEnter={req_auth}/>
			<Route path="requests" component={Acceptance} onEnter={req_auth}/>
			<Route path="connections" component={Connections} onEnter={req_auth}/>
			<Route path="results/:name" component={SearchResults} onEnter={req_auth}/>
			<Route path="advanced" component={AdvancedSearch} onEnter={req_auth}/>
			<Companies path="companies" component={Companies} onEnter={req_auth}/>
		</Route>
	</Router>
);

module.exports= routes;