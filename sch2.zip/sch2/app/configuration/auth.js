var firebase = require('firebase');
var history = require('react-router').hashHistory;

function Require_Auth(nextState) {
	var directingToPath = nextState.routes[0].path;

	firebase.auth().onAuthStateChanged(function(user) {
	  	if (user == null) {
	  		history.push('/login');}
	});
};
module.exports = Require_Auth;