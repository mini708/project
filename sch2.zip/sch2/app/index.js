var React = require('react');
var ReactDOM = require('react-dom');
var firebase = require('firebase');
var Router = require('react-router').Router;
var Route = require('react-router').Route;
var Link = require('react-router').Link;
var hashHistory = require('react-router').hashHistory;

var routes = require('./configuration/routes.js');

var config = {
		apiKey: "AIzaSyACkNNPEC__MRXjlVzV1NknmR7mpnvAahM",
  		authDomain: "schlink-b5eb1.firebaseapp.com",
  		databaseURL: "https://schlink-b5eb1.firebaseio.com",
  		storageBucket: "schlink-b5eb1.appspot.com",
  		messagingSenderId: "740330414123"
	};
firebase.initializeApp(config);

ReactDOM.render(routes, document.getElementById('app'));