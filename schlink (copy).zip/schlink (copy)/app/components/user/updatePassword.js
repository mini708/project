var React = require('react');
var firebase = require('firebase');
var Link = require('react-router').Link;
var hashHistory = require('react-router').hashHistory;

var UpdatePassword = React.createClass({
	getInitialState: function(){
		return{hasError: false, succeeded: false, errorMsg: "", successMsg: ""};
	},
	handleUpdatePassword: function(){
		if(true){
			var new_password = this.refs.new_password.value;
			var new_password_confirmation = this.refs.new_password_confirmation.value;
			var that = this;
			if(new_password && new_password_confirmation && new_password == new_password_confirmation){
				var user = firebase.auth().currentUser;
				user.updatePassword(new_password).then(function(){
					hashHistory.push('/');
				}, function(error){
					that.setState({hasError: true});
					that.setState({errorMsg: "An error occured!"});
				});
			}else{
				that.setState({hasError: true});
				that.setState({errorMsg: "Passwords do not match."});
			}
			this.refs.new_password.value = "";
			this.refs.new_password_confirmation.value = "";
		}
	},
	errorMessage: function(){
		return <div className="alert alert-danger"><strong>Error! </strong>{this.state.errorMsg}</div>;
	},
	noErrorMessage: function(){
		return <div></div>;
	},
	handleKeyPress: function(e){
		if(e.key == 'Enter'){
			try{
				this.handleUpdatePassword();
			}
			catch(e){};
		}
	},

	render: function(){
	var errorAlert;
		if(this.state.hasError){
			errorAlert = this.errorMessage();
		}else{
			errorAlert = this.noErrorMessage();
		}

		return (
			<div>
				{errorAlert}
				<input type="password" ref="new_password" placeholder="New Password" className="form-control" onKeyPress={this.handleKeyPress}/><br />
				<input type="password" ref="new_password_confirmation" placeholder="Confirm New Password" className="form-control" onKeyPress={this.handleKeyPress}/><br />
						
				<button onClick={this.handleUpdatePassword} className="btn btn-primary">Update Password</button><br />
			</div>
		);
	}
});

module.exports = UpdatePassword;
