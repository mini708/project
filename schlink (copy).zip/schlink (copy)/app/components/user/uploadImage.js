var React = require('react');
var ReactDOM = require('react-dom');
var firebase = require('firebase');
var Link = require('react-router').Link;
var hashHistory = require('react-router').hashHistory;

var UploadImage = React.createClass({
    getInitialState: function(){	
        return{imgRef: "", currentUser: ""};
    },

    handleUploadImage: function(){
		var storage = firebase.storage();
		var file = document.getElementById('input').files[0];
		var metadata = {
			contentType: 'image/jpeg'
		};
var uploadTask = storage.ref('images/' + firebase.auth().currentUser.uid + '/default.jpg' ).put(file, metadata);
	uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED, 
			function(snapshot) {
				// progress of image -> paused, running or how much uploaded
				var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
				console.log('Upload is ' + progress + '% done');
				switch (snapshot.state) {
					case firebase.storage.TaskState.PAUSED: 
						console.log('Upload is paused');
						break;
					case firebase.storage.TaskState.RUNNING: 
						console.log('Upload is running');
						break;
				}
			}, function(error) {
			switch (error.code) { // check errors like permission or cancel the upload or unknown error 
				case 'storage/unauthorized':
					break;
				case 'storage/canceled':
					break;
				case 'storage/unknown':
					break;
			}
			}, function() {
				var downloadURL = uploadTask.snapshot.downloadURL;
			});

		var user = firebase.auth().currentUser;
        var pathReference = storage.ref('images/' +  user.uid + '/default.jpg');
        pathReference.getDownloadURL().then(url => {
            this.setState({ imgRef: url });
        });
    },
	componentWillMount: function(){
		var storage = firebase.storage();
		var pathReference = storage.ref('images/default.jpg'); 
		
		firebase.auth().onAuthStateChanged((user) => {
			pathReference = storage.ref('images/' + user.uid + '/default.jpg');
			pathReference.getDownloadURL().then(url => {
				this.setState({
					imgRef: url
				});
			});
		});
	},

    render: function(){
        return (
            <div>
                <img src={this.state.imgRef}
                     className="img-circle" 
					alt="" width="140" 
					height="140"/>
				
				<br />
				<input type="file" id="input"  onChange={this.handleUploadImage} />
				
				<br />
				<br />
            </div>
        );
    }
});

module.exports = UploadImage;
