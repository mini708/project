var React = require('react');
var firebase = require('firebase');
var Link = require('react-router').Link;
var hashHistory = require('react-router').hashHistory;

var opportunityListings = React.createClass({
	getInitialState: function(){
		return{isCurrentUser: false, editing: false, opportunitylistings: [], id: this.props.pageID};
	},
	componentWillMount: function(){
        this.opportunitylistingRef = firebase.database().ref().child('user-opportunitylisting/'+this.props.pageID);
        this.opportunitylistingRef.on("child_added", snap => {
        	var opportunitylisting = snap.val();
			if(opportunitylisting){
				opportunitylisting.key = snap.ref.key;
			this.state.opportunitylistings.push(opportunitylisting);
				this.setState({opportunitylistings: this.state.opportunitylistings});
			}
        });

        this.opportunitylistingRefChanged = firebase.database().ref().child('user-opportunitylisting/'+this.props.pageID);
        this.opportunitylistingRefChanged.on("child_changed", snap => {
        	var opportunitylisting = snap.val();
			if(opportunitylisting){
				opportunitylisting.key = snap.ref.key;

				var index;
				for(var i = 0; i < this.state.opportunitylistings.length; i++){
					if(this.state.opportunitylistings[i].key == opportunitylisting.key){
						index = i;
					}
				}

				this.state.opportunitylistings.splice(index, 1, opportunitylisting);
				this.setState({opportunitylistings: this.state.opportunitylistings});
			}
        });

        this.opportunitylistingRefRemoved = firebase.database().ref().child('user-opportunitylisting/'+this.props.pageID);
        this.opportunitylistingRefRemoved.on("child_removed", snap => {
        	var opportunitylisting = snap.val();
			if(opportunitylisting){
				opportunitylisting.key = snap.ref.key;

				var index;
				for(var i = 0; i < this.state.opportunitylistings.length; i++){
					if(this.state.opportunitylistings[i].key == opportunitylisting.key){
						index = i;
					}
				}

				this.state.opportunitylistings.splice(index, 1);
				this.setState({opportunitylistings: this.state.opportunitylistings});
			}
        });
	},

	componentWillReceiveProps: function(nextProps){
		if(nextProps.pageID != this.state.id){
			this.opportunitylistingRef.off(); 
			this.opportunitylistingRefChanged.off();
			this.opportunitylistingRefRemoved.off();
			this.setState({opportunitylistings: []});

			this.opportunitylistingRef = firebase.database().ref().child('user-opportunitylisting/'+ nextProps.pageID);
	        this.opportunitylistingRef.on("child_added", snap => {
	        	var opportunitylisting = snap.val();
				if(opportunitylisting){
					opportunitylisting.key = snap.ref.key;
					this.state.opportunitylistings.push(opportunitylisting);
					this.setState({opportunitylistings: this.state.opportunitylistings});
				}
	        });

	        this.opportunitylistingRefChanged = firebase.database().ref().child('user-opportunitylisting/' + nextProps.pageID);
	        this.opportunitylistingRefChanged.on("child_changed", snap => {
	        	var opportunitylisting = snap.val();
				if(opportunitylisting){
					opportunitylisting.key = snap.ref.key;

					var index;
					for(var i = 0; i < this.state.opportunitylistings.length; i++){
						if(this.state.opportunitylistings[i].key == opportunitylisting.key){
							index = i;
						}
					}
					
					this.state.opportunitylistings.splice(index, 1, opportunitylisting);
					this.setState({opportunitylistings: this.state.opportunitylistings});
				}
	        });

	        this.opportunitylistingRefChanged = firebase.database().ref().child('user-opportunitylisting/' + nextProps.pageID);
	        this.opportunitylistingRefChanged.on("child_removed", snap => {
	        	var opportunitylisting = snap.val();
				if(opportunitylisting){
					opportunitylisting.key = snap.ref.key;

					var index;
					for(var i = 0; i < this.state.opportunitylistings.length; i++){
						if(this.state.opportunitylistings[i].key == opportunitylisting.key){
							index = i;
						}
					}
					
					this.state.opportunitylistings.splice(index, 1);
					this.setState({opportunitylistings: this.state.opportunitylistings});
				}
	        });
    	}
	},

	handleClickAdd: function(){
		this.setState({adding: true});
	},

	handleClickEdit: function(index){
		this.setState({editing: true});
		this.setState({indexToEdit: index});
	},

	handleClickSave: function(){
		var opportunitylistingData = {
			position: this.refs.position.value,
			industry: this.refs.industry.value,
			employmentType: this.refs.employmentType.value,
			experienceLevel: this.refs.experienceLevel.value,
			payrate: this.refs.payrate.value,
			location: this.refs.location.value,
			description: this.refs.description.value,
			responsibilities: this.refs.responsibilities.value,
			qualitifications: this.refs.qualitifications.value
		}

		if(this.state.editing){
			var opportunitylistingUpdate = {};
			opportunitylistingUpdate['/user-opportunitylisting/' + this.props.pageID + '/' + this.state.opportunitylistings[this.state.indexToEdit].key] = opportunitylistingData;
			firebase.database().ref().update(opportunitylistingUpdate);
		}else{
			var newExperienceKey = firebase.database().ref().child('opportunitylisting').push().key;
			firebase.database().ref('/user-opportunitylisting/' + this.props.pageID + '/' + newExperienceKey).set(opportunitylistingData);
		}
		
		this.setState({editing: false});
		this.setState({adding: false});

	},

	handleRemoveExisting: function(){
		var opportunitylistingRef = firebase.database().ref('user-opportunitylisting/' + this.props.pageID + '/' + this.state.opportunitylistings[this.state.indexToEdit].key);
		opportunitylistingRef.remove();

		this.setState({editing: false});
		this.setState({adding: false});
	},

	handleClickCancel: function(){
		this.setState({editing: false});
		this.setState({adding: false});
	},

	opportunitylistingHeading: function(){
		if(this.props.isCurrentUser){
			return <h2 className="profile-heading">Opportunity Listings <button className="btn btn-default" onClick={this.handleClickAdd}><span className="glyphicon glyphicon-plus" title="Add New Listing"></span></button></h2>
		}else{
			return <h2 className="profile-heading">Opportunity Listings</h2>
		}
	},

	addingExperience: function(){
		return(
			<div className="col-md-12">
				<div className="col-md-8">
					
					<div className="profile-heading">Course<button className="btn btn-default" onClick={this.handleClickAdd}><span className="glyphicon glyphicon-plus" title="Add New Listing"></span></button>
					<input type="text" ref="payrate" className="form-control" placeholder="Degree"/><br />
					<input type="text" ref="location" className="form-control" placeholder="Stream"/><br />
						<center>
							<div className="btn btn-toolbar">
								<button className="btn btn-primary" onClick={this.handleClickSave}>Save</button>
								<button className="btn btn-default" onClick={this.handleClickCancel}>Cancel</button>
							</div>
						</center><br/>
					</div>
<div className="profile-heading">Graduation Year<button className="btn btn-default" onClick={this.handleClickAdd}><span className="glyphicon glyphicon-plus" title="Add New Listing"></span></button>
					<input type="text" ref="payrate" className="form-control" placeholder="Year"/><br />
						<center>
							<div className="btn btn-toolbar">
								<button className="btn btn-primary" onClick={this.handleClickSave}>Save</button>
								<button className="btn btn-default" onClick={this.handleClickCancel}>Cancel</button>
							</div>
						</center><br/>
					</div>
					
					<input type="text" ref="payrate" className="form-control" placeholder="Scholarship Amount"/><br />
					<input type="text" ref="location" className="form-control" placeholder="Location"/><br />
					<textarea className="form-control" rows="6" style={{width: '100%'}} ref="responsibilities" placeholder="Step Wise Process"/><br/>
					<textarea className="form-control" rows="6" style={{width: '100%'}} ref="qualitifications" placeholder="Program Outcome"/><br/>
					<center>
						<div className="btn btn-toolbar">
							<button className="btn btn-primary" onClick={this.handleClickSave}>Save</button>
							<button className="btn btn-default" onClick={this.handleClickCancel}>Cancel</button>
						</div>
					</center><br/>
				</div>
			</div>
		)
	},

	editingExperience: function(){
		var indexedExperience = this.state.opportunitylistings[this.state.indexToEdit];

		return(
			<div className="col-md-12">
				<div className="col-md-8">
					<input type="text" ref="position" className="form-control" defaultValue={indexedExperience.position} /><br />
					<input type="text" ref="industry" className="form-control" defaultValue={indexedExperience.industry} /><br />
					<input type="text" ref="employmentType" className="form-control" defaultValue={indexedExperience.employmentType} /><br />
					<input type="text" ref="experienceLevel" className="form-control" defaultValue={indexedExperience.experienceLevel} /><br />
					<input type="text" ref="payrate" className="form-control" defaultValue={indexedExperience.payrate}/><br />
					<input type="text" ref="location" className="form-control" defaultValue={indexedExperience.location}/><br />
					<textarea className="form-control" rows="6" style={{width: '100%'}} ref="description" defaultValue={indexedExperience.description}/><br/>
					<textarea className="form-control" rows="6" style={{width: '100%'}} ref="responsibilities" defaultValue={indexedExperience.responsibilities}/><br/>
					<textarea className="form-control" rows="6" style={{width: '100%'}} ref="qualitifications" defaultValue={indexedExperience.qualitifications}/><br/>

					<center>
						<div className="btn btn-toolbar">
							<button className="btn btn-primary" onClick={this.handleClickSave}>Save</button>
							<button className="btn btn-default" onClick={this.handleClickCancel}>Cancel</button>
							<button className="btn btn-link" onClick={this.handleRemoveExisting}>Remove this listing</button>
						</div>
					</center><br/>
				</div>
			</div>
		)
	},

	defaultExperience: function(){
		if(this.props.isCurrentUser){
			return(
				<div>
					{this.state.opportunitylistings.map((opportunitylisting,index) => (
			        	<div key={index}>
			       			<h4><strong>{index + 1}. {opportunitylisting.position}</strong> <button className="btn btn-default" onClick={this.handleClickEdit.bind(null, index)}><span className="glyphicon glyphicon-pencil" title="Edit Listing"></span></button></h4>
			       			<h6>Industry: {opportunitylisting.industry}</h6>
			       			<h6>Employment Type: {opportunitylisting.employmentType}</h6>
			       			<h6>Experience Level: {opportunitylisting.experienceLevel}</h6>
			       			<h6>Pay Rate: {opportunitylisting.payrate}</h6>
			       			<h6>Location: {opportunitylisting.location}</h6>
			       			<h5><strong>opportunity Description</strong></h5>
			       			<h6><pre style={{margin: "-10px 0px 0px -10px", fontFamily: "helvetica", border: "none", width: "100%", background: "none", whiteSpace: "pre-wrap"}}>{opportunitylisting.description}</pre></h6>
			       			<h5><strong>Responsibilities</strong></h5>
			       			<h6><pre style={{margin: "-10px 0px 0px -10px", fontFamily: "helvetica", border: "none", width: "100%", background: "none", whiteSpace: "pre-wrap"}}>{opportunitylisting.responsibilities}</pre></h6>
			       			<h5><strong>Qualifications</strong></h5>
			       			<h6><pre style={{margin: "-10px 0px 0px -10px", fontFamily: "helvetica", border: "none", width: "100%", background: "none", whiteSpace: "pre-wrap"}}>{opportunitylisting.qualitifications}</pre></h6>
			       		</div>
			   		))}
				</div>
			)
		}else{
			return(
				<div>
					{this.state.opportunitylistings.map((opportunitylisting,index) => (
			        	<div key={index}>
			       			<h4><strong>{index + 1}. {opportunitylisting.position}</strong></h4>
			       			<h6>Industry: {opportunitylisting.industry}</h6>
			       			<h6>Employment Type: {opportunitylisting.employmentType}</h6>
			       			<h6>Experience Level: {opportunitylisting.experienceLevel}</h6>
			       			<h6>Pay Rate: {opportunitylisting.payrate}</h6>
			       			<h6>Location: {opportunitylisting.location}</h6>
			       			<h5><strong>opportunity Description</strong></h5>
			       			<h6><pre style={{margin: "-10px 0px 0px -10px", fontFamily: "helvetica", border: "none", width: "100%", background: "none", whiteSpace: "pre-wrap"}}>{opportunitylisting.description}</pre></h6>
			       			<h5><strong>Responsibilities</strong></h5>
			       			<h6><pre style={{margin: "-10px 0px 0px -10px", fontFamily: "helvetica", border: "none", width: "100%", background: "none", whiteSpace: "pre-wrap"}}>{opportunitylisting.responsibilities}</pre></h6>
			       			<h5><strong>Qualifications</strong></h5>
			       			<h6><pre style={{margin: "-10px 0px 0px -10px", fontFamily: "helvetica", border: "none", width: "100%", background: "none", whiteSpace: "pre-wrap"}}>{opportunitylisting.qualitifications}</pre></h6>
			       			<br />
			       		</div>
			   		))}
				</div>
			)
		}
	},

	render: function(){
		var show;

		if(this.state.adding){
			show = this.addingExperience();
		}else if(this.state.editing){
			show = this.editingExperience();
		}else{
			show = this.defaultExperience();
		}

		return (
			<div>
				{this.opportunitylistingHeading()}
				{show}
				<hr />
			</div>
		)
	},

	componentWillUnmount: function(){
		this.opportunitylistingRef.off();
		this.opportunitylistingRefChanged.off();
		this.opportunitylistingRefRemoved.off();
	},
});

module.exports = opportunityListings;
